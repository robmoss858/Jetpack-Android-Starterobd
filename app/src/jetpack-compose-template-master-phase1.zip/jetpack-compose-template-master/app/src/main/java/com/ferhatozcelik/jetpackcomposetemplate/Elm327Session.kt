package com.ferhatozcelik.jetpackcomposetemplate

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout

class Elm327Session(
    private val channel: ElmByteChannel
) {
    private val mutex = Mutex()

    suspend fun sendCommand(cmd: String, timeoutMs: Long = 2500L): String = mutex.withLock {
        withContext(Dispatchers.IO) {
            withTimeout(timeoutMs) {
                // Drain any stale bytes from previous responses
                val drainBuf = ByteArray(256)
                while (channel.available() > 0) {
                    val read = channel.read(drainBuf, 0, minOf(drainBuf.size, channel.available()))
                    if (read <= 0) break
                }

                channel.write("$cmd\r".toByteArray(Charsets.US_ASCII))

                val response = StringBuilder()
                val buffer = ByteArray(1024)
                while (isActive) {
                    val avail = channel.available()
                    if (avail > 0) {
                        val bytesRead = channel.read(buffer, 0, minOf(buffer.size, avail))
                        if (bytesRead == -1) break
                        if (bytesRead > 0) {
                            val chunk = String(buffer, 0, bytesRead, Charsets.US_ASCII)
                            response.append(chunk)
                            if (response.contains(">")) break
                        }
                    } else {
                        delay(10)
                    }
                }

                response.toString()
                    .replace(">", "")
                    .trim()
            }
        }
    }

    suspend fun initializeForFordCan(targetHeader: String = "7E0") {
        sendCommand("AT Z", timeoutMs = 3500L)
        val initCommands = listOf(
            "AT E0",   // Echo off
            "AT L0",   // Linefeeds off
            "AT S0",   // Spaces off
            "AT H1",   // Headers on (e.g., 7E8 for PCM)
            "AT AL",   // Allow long (>7 byte) ISO-TP messages
            "AT CAF1", // CAN automatic formatting on
            "AT SP 6", // ISO 15765-4 CAN (11-bit ID, 500 kbaud) for 2005 Escape
            "AT SH $targetHeader"
        )
        for (cmd in initCommands) {
            sendCommand(cmd)
        }
    }

    suspend fun setHeader(header: String): String {
        return sendCommand("AT SH $header")
    }
}
